FAKE PAYMENT MOD - FABRIC 1.21.1
================================

BESCHRIJVING:
=============
Een Donut SMP-style FAKE betaalsysteem voor je eigen server!

Spelers kunnen `/pay <naam> <bedrag>` gebruiken en krijgen een mooie betaal-confirmation met:
- 🔊 "DING!" geluid (zoals op Donut SMP)
- 💰 Mooie betaal-scherm in Donut SMP stijl
- 📢 Broadcast naar alle spelers
- ✓ Bedrag wordt opgeslagen

COMMANDS:
=========

1. /pay <spelernaam> <bedrag>
   - Registreert betaling van de speler
   - Geeft Donut SMP-style betaal-bevestiging
   - Speelt "ding!" geluid af
   - Broadcast naar alle spelers
   
   Voorbeelden:
   /pay Steve 9.99
   /pay Alex 19.99
   /pay Jan 4.99

2. /betaaldlijst
   - Laat alle betaalde spelers zien
   - Toont bedrag per speler
   
   Voorbeeld: /betaaldlijst

3. /unbetaald <spelernaam>
   - Verwijdert betaal-status van een speler
   - Undo de /pay command
   
   Voorbeeld: /unbetaald Steve

BUILD & INSTALLATIE:
====================

WINDOWS:
1. Unzip FakePaymentMod.zip
2. Open Command Prompt in de folder
3. Type: gradlew build
4. Wacht tot het klaar is (2-3 minuten)

MAC/LINUX:
1. Unzip FakePaymentMod.zip
2. Open Terminal in de folder
3. Type: ./gradlew build
4. Wacht tot het klaar is

JAR LOCATIE:
- build/libs/fakepay-1.0.0.jar

INSTALLATIE IN MINECRAFT:
=========================
1. Zet je Fabric loader 1.21.1
2. Copy fakepay-1.0.0.jar → .minecraft/mods folder
3. Start Minecraft → Mod is ingeladen!

FEATURES:
=========
✓ /pay <naam> <bedrag> command
✓ Donut SMP-style betaal-bevestiging (goud borders)
✓ 🔊 "DING!" geluid effect (ENTITY_PLAYER_LEVELUP)
✓ 📢 Broadcast naar alle spelers
✓ Bedrag opslaan per speler
✓ Betaaldlijst bekijken
✓ Betaling verwijderen (/unbetaald)
✓ Werkt multiplayer

BETAAL SCHERM:
==============
Wanneer je `/pay <naam> <bedrag>` doet, ziet de speler:

╔════════════════════════════════════╗
║      ✓ BETALING GEACCEPTEERD       ║
╠════════════════════════════════════╣
║ Bedrag: €9.99
║ Status: ✓ BETAALD
║ Speler: <naam>
╠════════════════════════════════════╣
║ Je hebt nu PREMIUM access!
║ Geniet van je voordelen!
╚════════════════════════════════════╝

Plus: 🔊 DING! geluid!

Vragen? Zeg me wat je wilt toevoegen!
