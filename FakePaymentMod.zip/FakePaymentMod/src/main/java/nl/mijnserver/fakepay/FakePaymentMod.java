package nl.mijnserver.fakepay;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class FakePaymentMod implements ModInitializer {

    public static final String MOD_ID = "fakepay";

    // Betaalde spelers opslaan
    private static final Map<UUID, Double> paidPlayers = new HashMap<>();

    // Aangepaste namen per speler (zodat je andere naam kan laten zien)
    private static final Map<UUID, String> customNames = new HashMap<>();

    // Aan/Uit toggle
    private static boolean modEnabled = true;

    @Override
    public void onInitialize() {
        registerCommands();
        System.out.println("[FakePayment] Donut SMP Fake Pay Mod gestart!");
    }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            // /pay <speler> <bedrag>
            dispatcher.register(
                net.minecraft.server.command.CommandManager.literal("pay")
                    .then(net.minecraft.server.command.CommandManager.argument("speler", StringArgumentType.word())
                        .then(net.minecraft.server.command.CommandManager.argument("bedrag", FloatArgumentType.floatArg(0.01f, 9999.99f))
                            .executes(ctx -> payCommand(
                                ctx.getSource(),
                                StringArgumentType.getString(ctx, "speler"),
                                FloatArgumentType.getFloat(ctx, "bedrag")
                            ))
                        )
                    )
            );

            // /payname <speler> <naam> — verander de weergavenaam van een speler
            dispatcher.register(
                net.minecraft.server.command.CommandManager.literal("payname")
                    .then(net.minecraft.server.command.CommandManager.argument("speler", StringArgumentType.word())
                        .then(net.minecraft.server.command.CommandManager.argument("naam", StringArgumentType.word())
                            .executes(ctx -> setNameCommand(
                                ctx.getSource(),
                                StringArgumentType.getString(ctx, "speler"),
                                StringArgumentType.getString(ctx, "naam")
                            ))
                        )
                    )
            );

            // /paytoggle — zet de mod aan of uit
            dispatcher.register(
                net.minecraft.server.command.CommandManager.literal("paytoggle")
                    .executes(ctx -> toggleCommand(ctx.getSource()))
            );

            // /paylist — lijst van betaalde spelers
            dispatcher.register(
                net.minecraft.server.command.CommandManager.literal("paylist")
                    .executes(ctx -> listCommand(ctx.getSource()))
            );

            // /unpay <speler> — betaling verwijderen
            dispatcher.register(
                net.minecraft.server.command.CommandManager.literal("unpay")
                    .then(net.minecraft.server.command.CommandManager.argument("speler", StringArgumentType.word())
                        .executes(ctx -> unpayCommand(
                            ctx.getSource(),
                            StringArgumentType.getString(ctx, "speler")
                        ))
                    )
            );
        });
    }

    // ──────────────────────────────────────────────
    // /pay <speler> <bedrag>
    // ──────────────────────────────────────────────
    private static int payCommand(ServerCommandSource source, String playerName, float amount) {
        if (!modEnabled) {
            source.sendError(Text.literal("§cFake Pay Mod is uitgeschakeld! Gebruik /paytoggle om aan te zetten."));
            return 0;
        }

        var server = source.getServer();
        ServerPlayerEntity target = server.getPlayerManager().getPlayer(playerName);

        if (target == null) {
            source.sendError(Text.literal("§cSpeler '" + playerName + "' niet gevonden of is niet online."));
            return 0;
        }

        UUID uuid = target.getUuid();

        // Pak de aangepaste naam, of de echte naam als er geen is ingesteld
        String displayName = customNames.getOrDefault(uuid, target.getName().getString());

        // Sla de betaling op
        paidPlayers.put(uuid, (double) amount);

        // ── Bericht in EXACT Donut SMP stijl ──
        // Aqua naam, geel bedrag — zoals in de screenshot
        Text payMessage = Text.literal("You paid ")
            .append(Text.literal(displayName).styled(s -> s.withColor(0x55FFFF)))  // aqua
            .append(Text.literal(" $" + formatAmount(amount)).styled(s -> s.withColor(0xFFFF55)));  // geel

        // Action bar (midden scherm boven hotbar)
        target.sendMessage(payMessage, true);

        // Chat bericht
        target.sendMessage(payMessage, false);

        // Geluid (Donut SMP ding!)
        target.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0f, 1.5f);

        // Bevestiging voor degene die het commando uitvoerde
        source.sendFeedback(
            () -> Text.literal("§a✔ Betaling verstuurd naar §b" + displayName + " §a($" + formatAmount(amount) + ")"),
            false
        );

        System.out.println("[FakePayment] Betaling: " + displayName + " -> $" + formatAmount(amount));
        return Command.SINGLE_SUCCESS;
    }

    // ──────────────────────────────────────────────
    // /payname <speler> <naam>
    // ──────────────────────────────────────────────
    private static int setNameCommand(ServerCommandSource source, String playerName, String newName) {
        var server = source.getServer();
        ServerPlayerEntity target = server.getPlayerManager().getPlayer(playerName);

        if (target == null) {
            source.sendError(Text.literal("§cSpeler '" + playerName + "' niet gevonden."));
            return 0;
        }

        customNames.put(target.getUuid(), newName);
        source.sendFeedback(
            () -> Text.literal("§a✔ Naam van §f" + playerName + " §ais nu ingesteld op: §b" + newName),
            false
        );
        return Command.SINGLE_SUCCESS;
    }

    // ──────────────────────────────────────────────
    // /paytoggle
    // ──────────────────────────────────────────────
    private static int toggleCommand(ServerCommandSource source) {
        modEnabled = !modEnabled;
        if (modEnabled) {
            source.sendFeedback(() -> Text.literal("§a✔ Fake Pay Mod is nu AANGESCHAKELD"), false);
        } else {
            source.sendFeedback(() -> Text.literal("§c✖ Fake Pay Mod is nu UITGESCHAKELD"), false);
        }
        System.out.println("[FakePayment] Mod " + (modEnabled ? "AAN" : "UIT") + "geschakeld.");
        return Command.SINGLE_SUCCESS;
    }

    // ──────────────────────────────────────────────
    // /paylist
    // ──────────────────────────────────────────────
    private static int listCommand(ServerCommandSource source) {
        if (paidPlayers.isEmpty()) {
            source.sendFeedback(() -> Text.literal("§eGeen spelers hebben betaald."), false);
            return 0;
        }
        source.sendFeedback(() -> Text.literal("§6── Betaalde spelers ──"), false);
        paidPlayers.forEach((uuid, amt) -> {
            var p = source.getServer().getPlayerManager().getPlayer(uuid);
            String name = customNames.getOrDefault(uuid, p != null ? p.getName().getString() : uuid.toString());
            source.sendFeedback(() -> Text.literal("§a✓ §b" + name + " §f- §e$" + formatAmount(amt)), false);
        });
        return Command.SINGLE_SUCCESS;
    }

    // ──────────────────────────────────────────────
    // /unpay <speler>
    // ──────────────────────────────────────────────
    private static int unpayCommand(ServerCommandSource source, String playerName) {
        var server = source.getServer();
        ServerPlayerEntity target = server.getPlayerManager().getPlayer(playerName);

        if (target == null) {
            source.sendError(Text.literal("§cSpeler '" + playerName + "' niet gevonden."));
            return 0;
        }

        UUID uuid = target.getUuid();
        if (!paidPlayers.containsKey(uuid)) {
            source.sendError(Text.literal("§e" + playerName + " heeft nog niet betaald."));
            return 0;
        }

        paidPlayers.remove(uuid);
        source.sendFeedback(
            () -> Text.literal("§c✔ Betaling van §f" + playerName + " §cverwijderd."),
            false
        );
        return Command.SINGLE_SUCCESS;
    }

    // Bedrag formatteren: als het een heel getal is, geen decimalen
    private static String formatAmount(double amount) {
        if (amount == Math.floor(amount)) {
            return String.valueOf((int) amount);
        }
        return String.format("%.2f", amount);
    }

    public static boolean hasPlayerPaid(UUID uuid) { return paidPlayers.containsKey(uuid); }
    public static boolean isEnabled() { return modEnabled; }
}
